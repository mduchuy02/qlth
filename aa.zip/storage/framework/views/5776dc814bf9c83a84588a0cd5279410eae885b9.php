<?php echo e($slot); ?>

<?php /**PATH D:\CONG NGHE THONG TIN\HK8\LuanVanTotNghiep\luanvan_ratruong\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>